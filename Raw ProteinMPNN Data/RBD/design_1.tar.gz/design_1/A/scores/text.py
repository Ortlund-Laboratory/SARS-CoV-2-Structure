import numpy as np

data = np.load('stripped_7vnu_renum.npz', allow_pickle=True)
lst = data.files

for item in lst:
    print(item)
    print(data[item])
